Win32 used to build with Visual Studio 6, but we now use cmake.

This file needs to be adopted by a windows expert developer.
